from setuptools import setup

setup(name='SolNE',
      version='1.0',
      description='Installation of SolNE Package',
      url='#',
      author='Christian Alpizar, Esteban Campos, Andrey Sibaja, Jose Ortega',
      author_email='christianalpizar99@gmail.com, estebandcg1999@gmail.com, diego.garro120@gmail.com, ortega.josant@gmail.com',
      license='MIT',
      packages=['SolNE'],
      zip_safe=False)
