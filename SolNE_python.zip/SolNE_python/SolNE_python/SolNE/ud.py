from sympy import *
import math 

x = symbols('x')


import matplotlib.pyplot


def graph(axis_x, axis_y, title):
    """
    Makes graphs to see Iterations vs |f(x)| evaluations
    :param axis_x: Array with numeric values to x axis
    :param axis_y: Array with numeric values to y axis
    :param title: String - graph's name
    :return: Shows graph
    """

    matplotlib.pyplot.plot(axis_x, axis_y)

    matplotlib.pyplot.axhline(0, color="black")
    matplotlib.pyplot.axvline(0, color="black")
    matplotlib.pyplot.xlabel("Iterations", fontdict=None, labelpad=None)
    matplotlib.pyplot.ylabel("|f(x)|", fontdict=None, labelpad=None)
    matplotlib.pyplot.title(title)

    matplotlib.pyplot.show()



def sne_ud_1(f, xk, tol, graff=1):
    """
    This function find solution to non lineal equation using Ostrowski's method.
    Ostrowski's method use an inicitial value(x0) to start solving the equation.

    Retrieved from: Penkova M. METODOS ITERATIVOS EFICIENTES PARA
    LA RESOLUCION DE SISTEMAS NO LINEALES. Universitat Politècnica de València.

    :param f: Type STRING. Math expression to evaluate
    :param xk: Type FLOAT or INTEGER. Initial value for X
    :param tol: Type FLOAT or INTEGER. Minimum approach tolerance
    :param graff: Type INTEGER. Indicates if you want a graph or not.
    :return: Type: Tuple. (xk, iterations)
    """

    if not isinstance(f, str):
        return "Error: 'f' paramether must be str type"
    else:
        try:
            f = sympify(f)
        except:
            return "Syntax Error!"
        if ((len(f.atoms(Symbol)) > 1) or (not x in f.atoms(Symbol))):
            print("Syntax Error!")
            return
        df = diff(f, x)
        if df != 0:
            if isinstance(xk, float) or isinstance(xk, int):
                if isinstance(tol, float) or isinstance(tol, int):
                    fk = f.subs(x, xk).evalf()
                    dfk = df.subs(x, xk).evalf()
                    iter = 0
                    x_values = [iter]
                    y_values = [abs(fk)]
                    while abs(fk) > tol:
                        yk = xk - (fk / dfk)
                        if (fk - 2 * f.subs(x, yk).evalf()) * dfk == 0:
                            break
                        xk = (yk - (f.subs(x, yk).evalf() /
                                    (fk - 2 * f.subs(x, yk).evalf())) * (fk / dfk))

                        fk = f.subs(x, xk).evalf()
                        dfk = df.subs(x, xk).evalf()

                        iter += 1
                        x_values.append(iter)
                        y_values.append(abs(fk))

                    if graff == 1:
                        graph(x_values, y_values,
                              "Ostrowski's method to: f(x)=" + str(f))
                    elif graff != 0:
                        print("Warning: parameter graff must be an integer, 1 or 0")
                    return xk, iter
                else:
                    return "'tol' type error, must be float or integer"
            else:
                return "'xk' type error, must be float or integer"
        else:
            return "Error: f derivative must be different from 0"


def sne_ud_2(f, xk, tol, graff=1):
    """
    This function find solution to non lineal equation using Kou-Li's method.
    Kou-Li's method use an inicitial value(x0) to start solving the equation.

    Retrieved from: Prieto J.(2008) METODOS ITERATIVOS PARA RESOLVER
    ECUACIONES NO LINEALES. Tesis de Licenciatura. Universidad de Los Andes.

    :param f: Type STRING. Math expression to evaluate
    :param xk: Type FLOAT or INTEGER. Initial value for X
    :param tol: Type FLOAT or INTEGER. Minimum approach tolerance
    :param graff: Type INTEGER. Indicates if you want a graph or not.
    :return: Type: Tuple. (xk, iterations)
    """
    if not isinstance(f, str):
        return "Error: 'f' paramether must be str type"
    else:
        try:
            f = sympify(f)
        except:
            return "Syntax Error!"
        if ((len(f.atoms(Symbol)) > 1) or (not x in f.atoms(Symbol))):
            print("Syntax Error!")
            return
        df = diff(f, x)
        if df != 0:
            if isinstance(xk, float) or isinstance(xk, int):
                if isinstance(tol, float) or isinstance(tol, int):
                    fk = f.subs(x, xk).evalf()
                    dfk = df.subs(x, xk).evalf()
                    iter = 0
                    x_values = [iter]
                    y_values = [abs(fk)]
                    while abs(fk) > tol:
                        if dfk == 0:
                            break
                        yk = xk - (fk / dfk) / 2
                        if df.subs(x, yk).evalf() == 0:
                            break
                        xk = (xk - (fk / 2)
                              * ((1 / dfk) + (1 / (2 * df.subs(x, yk).evalf() - dfk))))

                        fk = f.subs(x, xk).evalf()
                        dfk = df.subs(x, xk).evalf()

                        iter += 1
                        x_values.append(iter)
                        y_values.append(abs(fk))

                    if graff == 1:
                        graph(x_values, y_values, "Kouli's method to: f(x)=" + str(f))
                    elif graff != 0:
                        print("Warning: parameter graff must be an integer, 1 or 0")

                    return xk, iter
                else:
                    return "'tol' type error, must be float or integer"
            else:
                return "'xk' type error, must be float or integer"
        else:
            return "Error: f derivative must be different from 0"


def sne_ud_3(fun, xo, tol, graph = 1):
    """
  Modified Newton Raphson Method
  This method csonsists in taking the known method of Newton Raphson, but with
  variation in its formula, this variation is adding the second derivate. This
  method has a faster convergence the normal NR.
  Retrieved from: Calderón, G. (2008). Métodos iterativos para resolver ecuaciones no lineales. [online]
  Available at: http://webdelprofesor.ula.ve/ciencias/giovanni/documentos/
  Publicaciones/Articulos/NotasMatematicasV32007.pdf

  :parameter xo: initial value for 'x'
  :param fun: math expression to evaluate
  :param tol: minimum approach tolerance
  :param graph: Integer, 1 or 0
  :return: Tuple, [x aproximation, iterations]
    """
    if not (isinstance(xo, float) or isinstance(xo, int)):
        print("Error, initial value its not valid")
        return

    if not (isinstance(tol, float) or isinstance(tol, int)):
        print("Error, tolerance isn't a valid number")
        return

    func = sympify(fun)

    if not isinstance(fun, str):
        return "Error : f paramether must be a str type"

    f = sympify(fun)
    variable = f.atoms(Symbol)
    if len(variable) > 1:
        return " Error: The f expression has more than one variables"
    if not x in variable:
        return " Error: The expression f doesn't have x as a variable"

    first_deriv = diff(func, x)
    sec_deriv = diff(first_deriv, x)

    iterations = 0
    x_values = [iterations]
    y_values = [xo]
    if (isinstance(xo, complex)):
        print("The initial value must belong to R")
        return
    elif (first_deriv == 0):
        print("Derivate cannot be equal to zero")
        return

    if (abs(func.subs(x, xo)) <= tol):
        return xo, 0
    else:
        while (True):
            if (abs(func.subs(x, xo)) <= tol):
                if graph == 1:
                    graph(x_values, y_values, "Newton Raphson Modified method f(x)")
                elif graph != 0:
                    print("Warning: parameter graff must be an integer, 1 or 0")
                return xo, iterations
            else:
                denominator = (first_deriv.subs(x, xo).evalf()) ** 2 -\
                              (func.subs(x, xo).evalf() * sec_deriv.subs(x, xo).evalf())
                if (denominator == 0):
                    print("Error, divition into zero")
                    break
                xo = xo - (func.subs(x, xo).evalf() * first_deriv.subs(x, xo).evalf()) / (denominator)
                iterations = iterations + 1

                x_values.append(iterations)
                y_values.append(abs(func.subs(x, xo).evalf()))


def sne_ud_4(fun, a, b, tol, graph = 1):
    """
     RFN Method
     The RFN method it consists in approximating the root of f, in each step,
     using the method of the Regula Falsi and the value obtained is used
    as the initial condition for the Newton-Raphson method.

    Retrieved from: Métodos iterativos para resolver
    ecuaciones no lineales. Online: http://webdelprofesor.ula.ve/ciencias/giovanni
    /documentos/Publicaciones/Articulos/NotasMatematicasV32007.pdf

    :parameter a: initial value for the interval.
    :parameter b: final value for the interval.
    :parameter fun: math expression to evaluate
    :param tol: minimum approach tolerance
    :param graph: Integer, 1 or 0
    :return: Tuple, [x aproximation, iterations]
    """

    if not isinstance(fun, str):
        return "Error : f paramether must be a str type"
    f = sympify(fun)
    variable = f.atoms(Symbol)
    if len(variable) > 1:
        return " Error: The f expression has more than one variables"
    if not x in variable:
        return " Error: The expression f doesn't have x as a variable"

    func = sympify(fun)
    iterations = 0
    d_fun = diff(func, x)
    a_eval = func.subs(x, a).evalf()
    b_eval = func.subs(x, b).evalf()
    bolzano = a_eval * b_eval
    denominator = b_eval - a_eval
    x_values = [iterations]
    y_values = []

    if  not(isinstance(a, float) or isinstance(a, int)) \
        or not(isinstance(b, float) or isinstance(b, int)):
        print("Error, interval value its not valid")
        return

    if not (isinstance(tol, float) or isinstance(tol, int)):
        print("Error, tolerance isn't a valid number")
        return

    if(bolzano > 0):
        print("The existence of one or a single zero in the "
              "given interval cannot be guaranteed.")
        return
    elif(bolzano == 0):
        if(a_eval == 0):
            y_values.append(abs(a_eval))
            return a_eval, 0
        else:
            y_values.append(abs(b_eval))
            return b_eval, 0

    if(denominator == 0):
        print("Error, division between zero, there's no aproximation to x")
        return

    z_n = (b * a_eval - a * b_eval) / denominator
    x_k = z_n - (func.subs(x, z_n).evalf() / d_fun.subs(x, z_n).evalf())

    y_values.append(abs(func.subs(x, x_k).evalf()))
    while(abs(func.subs(x, x_k).evalf()) >= tol):
        z_n_denominator = func.subs(x, b).evalf() - func.subs(x, a).evalf()
        if(z_n_denominator == 0):
            print("Warning. Division between zero, the x aproximation is: ", x_k)
            break
        z_n = b - (func.subs(x, b).evalf() * (b - a)) \
              / (z_n_denominator)
        x_k_denominator = d_fun.subs(x, z_n).evalf()
        if(x_k_denominator == 0):
            print("Warning. Division between zero, the x aproximation is: ", x_k)
            break
        x_k = z_n - (func.subs(x, z_n).evalf() / x_k_denominator)
        bolzano = func.subs(x, a).evalf() * func.subs(x, x_k).evalf()
        iterations = iterations + 1
        x_values.append(iterations)
        y_values.append(abs(func.subs(x, x_k).evalf()))
        if(bolzano < 0):
            b = x_k
        elif (bolzano > 0):
            a = x_k
    if graph == 1:
        graph(x_values, y_values, "RFN method f(x)")
    elif graph != 0:
        print("Warning: parameter graff must be an integer, 1 or 0")
    return x_k, iterations


def sne_ud_5(f, x1, tol, graff = 1):
    '''
    Halley's method uses the second derivate of the funtion f to
    produces iteratively a sequence of approximations to a zero of f.
    The method need one value to start and returns an x approximate 
    and number of iterations that is does.
    
    Reference: Džunic, J. O. V. A. N. A. (2012, August 24). 
    [Halley's method] [Paper]. Retrieved August 20, 2019,
    from https://link.springer.com/content/pdf/10.1007%2Fs11075-012-9641-3.pdf
    
    :param x1: (Type FLOAT/INTEGER) Initial Value for x
    :param tol:(Type FLOAT/INTEGER) approach tolerance
    :param f: (Type string) math funtion
    :param graff: (Type INTEGER) 1 to shown the graphic and 0 to don't shown
    :return: (Type TUPLE) X approximate and number of iterations
    '''
    if not isinstance(f, str):
        return "Error : f paramether must be a str type"
    f = sympify(f)
    variable = f.atoms(Symbol)
    if len(variable) > 1:
        return "Error: The f expression has more than one variables"  
    if not x in variable:
        return " Error: The expression f doesn't have x as a variable"
    df = diff(f)
    ddf = diff(df)
    if not(isinstance(x1, int)) and not(isinstance(x1 ,float)):
        return "Error: Incorrect initial value"
    if not(isinstance(tol, int)) and not(isinstance(tol, float)):
        return "Error: Incorrect tolerance" 
    try:
        iteraciones  = 1
        x_sig = (x1 - 2 * (f.subs(x, x1).evalf() * df.subs(x, x1).evalf()) / 
                 (2 * (df.subs(x, x1).evalf())**2 - 
                  f.subs(x, x1).evalf() * ddf.subs(x, x1).evalf())) 
        valores_x = [iteraciones]
        valores_y = [abs(f.subs(x, x_sig).evalf())]
        while(abs(x_sig - x1) >= tol):
            x1 = x_sig
            x_sig = (x1 - 2 * (f.subs(x, x1).evalf() * df.subs(x, x1).evalf()) / 
                     (2 * (df.subs(x, x1).evalf())**2 - 
                      f.subs(x, x1).evalf() * ddf.subs(x, x1).evalf()))
            iteraciones  += 1
            valores_x.append(iteraciones)
            valores_y.append(abs(f.subs(x, x_sig).evalf()))
        if graff == 1:
            graph(valores_x, valores_y, (
                    "Halley method: f(x)=" + str(f)))
        elif graff != 0:
            print ("Warnings: The graff value must be an integer, 0 or 1")
        return x_sig, iteraciones
    except ZeroDivisionError:
        print("Error: Divison by zero")
        return x_sig, iteraciones


def sne_ud_6(f, x0, d, tol, graf = 1):
    """
    Computes an aproximation of a zero of a function f with the Householder's
    Method. It uses the parameter 'x0' as the initial value required for the
    iterations; and the initial value 'd' that determines the order in which
    is going to be used the Householder's Method.
    It returns the aproximation of the zero with a precision of 'tol', the
    number of iterations required to find the solution and a graph of the
    number of iterations versus the error; only if its required.

    Retrieved from: Alston Scott (1970). The Numerical Treatment Of A Single
    Nonlinear Equation, Pag. 169.
    
    :param f: symbolic expression of the equation
    :type f: string

    :param x0: first initial value
    :type x0: int or float
	
    :param d: second initial value
    :type d: natural number

    :param tol: amount of precision on the result
    :type tol: float
	
    :param graf: flag that determines if the method needs to return a graph
    :type graf: 1 or 0 (1 by default)
                
    You need to install the SymPy and MatPlotLib package before using this
    method.
    
    :example: 'sne_ud_6("x ** 2 - 2", 1, 1, 0.0001)'
    """
    if(not isinstance(f, str)):
        print("The initial value 'f' must be a string!")
        return
    try:
        f = sympify(f)
    except:
        print("Syntax Error!")
        return
    if ((len(f.atoms(Symbol)) > 1) or (not x in f.atoms(Symbol))):
        print("Syntax Error!")
        return
    
    if(isinstance(x0, complex) or isinstance(tol, complex)):
        print("The initial values 'x0' and 'tol' must be real numbers!")
        return
    
    if((not isinstance(d, int)) or (d <= 0)):
        print("The initial value 'd' must be a natural number!")
        return
    
    n = 1
    numerator = 1 / f
    denominator = 1 / f
    while(n < d):
        numerator = diff(numerator, x)
        denominator = diff(denominator, x)
        n = n + 1
    denominator = diff(denominator, x)
    
    xk = x0
    k = 0
    x_vector = [k]
    y_vector = [abs(f.subs(x, xk).evalf())]
    try:
        while(abs(f.subs(x, xk)) > tol):
            xk = xk + d * (numerator.subs(x, xk).evalf() / \
                           denominator.subs(x, xk).evalf())
            
            k = k + 1
            x_vector.append(k)
            y_vector.append(abs(f.subs(x, xk).evalf()))
    except:
        print("You can't divide by zero!\nThe process has been stopped!")
    if(graf == 1):
        graph(x_vector, y_vector, "Householder's method to: f(x)=" + str(f))
    return xk, k
