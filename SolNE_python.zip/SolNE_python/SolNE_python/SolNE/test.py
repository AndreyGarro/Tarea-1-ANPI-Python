from fd import *
from ud import *


print(sne_fd_1("x**2-2", 1, 0.0001))
print(sne_fd_2("x**(-2)-2", 1, 2, 0.0001))
print(sne_fd_3("x**2-2", 3, 2, 1, 0.0001))
print(sne_fd_4("x**2-2", 1, 2, 0.0001))
print(sne_fd_5("x**2-2", 1, 2, 0.0001))
print(sne_fd_6("x**2-2", 1, 2, 0.0001))


print(sne_ud_1("x**2-2", 1, 0.0001))
print(sne_ud_2("x**2-2", 1, 0.0001))
print(sne_ud_3("x**2-2", 1, 0.0001))
print(sne_ud_4("x**2-2", 1, 2, 0.0001))
print(sne_ud_5("x**2-2", 1, 0.0001))
print(sne_ud_6("x**2-2", 1, 1, 0.0001))
