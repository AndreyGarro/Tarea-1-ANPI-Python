from sympy import *
import math


x = symbols('x')

import matplotlib.pyplot


def graph(axis_x, axis_y, title):
    """
    Makes graphs to see Iterations vs |f(x)| evaluations
    :param axis_x: Array with numeric values to x axis
    :param axis_y: Array with numeric values to y axis
    :param title: String - graph's name
    :return: Shows graph
    """

    matplotlib.pyplot.plot(axis_x, axis_y)

    matplotlib.pyplot.axhline(0, color="black")
    matplotlib.pyplot.axvline(0, color="black")
    matplotlib.pyplot.xlabel("Iterations", fontdict=None, labelpad=None)
    matplotlib.pyplot.ylabel("|f(x)|", fontdict=None, labelpad=None)
    matplotlib.pyplot.title(title)

    matplotlib.pyplot.show()



def calcular_distancia(a, b, c, d):
    """
  Calculates the nearest point to the other.
  :param a: existing point
  :param b: existing point
  :param c: existing point
  :param d: new point to compare
    """
    sum_dist_a = abs(a - d)
    sum_dist_b = abs(b - d)
    sum_dist_c = abs(c - d)

    total_sum = sum_dist_a + sum_dist_b + sum_dist_c

    if sum_dist_a >= sum_dist_b and sum_dist_a >= sum_dist_c:
        return [b, c, total_sum-sum_dist_a]
    elif sum_dist_b >= sum_dist_a and sum_dist_b >= sum_dist_c:
        return [a, c, total_sum-sum_dist_b]
    else:
        return [a, b, total_sum-sum_dist_c]


def muller_algorithm(x_a, x_b, x_c, fun):
    """
    Muller Algorithm
    It's the part needed of the algorithm for the method.
    :param x_a: first value of x.
    :param x_b: second value of x.
    :param x_c: third value of x.
    :param fun: math expression to evaluate.
    :return: the better aproximation of a new point.
    """
    A = symbols("A")
    B = symbols("B")
    C = symbols("C")

    x_a_eval = fun.subs(x, x_a).evalf()
    x_b_eval = fun.subs(x, x_b).evalf()
    x_c_eval = fun.subs(x, x_c).evalf()

    fun_a = A * x_a ** 2 + B * x_a + C - x_a_eval
    fun_b = A * x_b ** 2 + B * x_b + C - x_b_eval
    fun_c = A * x_c ** 2 + B * x_c + C - x_c_eval

    sys_solution = solve([fun_a, fun_b, fun_c], [A, B, C])

    A = sys_solution[A]
    B = sys_solution[B]
    C = sys_solution[C]

    new_fun = A * x ** 2 + B * x + C

    x_sol = solve(new_fun, x)

    points_dist_xo = calcular_distancia(x_a, x_b, x_c, x_sol[0])
    points_dist_x1 = calcular_distancia(x_a, x_b, x_c, x_sol[1])

    if(points_dist_xo[2] <= points_dist_x1[2]):
        return x_sol[0]
    else:
        return x_sol[1]


def sne_fd_1(f, xk, tol, graff=1):
    """
    This function find solution to non lineal equation using Steffensen's method.
    Steffensen's method use an inicitial value(x0) to start solving the equation.

    Retrieved from: Cordero A. & R. Torrogrosa J. (2011). A CLASS OF STEFFENSEN
    TYPE METHODS WITH OPTIMAL ORDER CONVERGENCE. Universidad Politecnica de Valencia

    :param f: Type STRING. Math expression to evaluate
    :param xk: Type FLOAT or INTEGER. Initial value for X
    :param tol: Type FLOAT or INTEGER. Minimum approach tolerance
    :param graff: Type INTEGER. Indicates if you want a graph or not.
    :return: Type: Tuple. (xk, iterations)
    """

    if not isinstance(f, str):
        return "Error: 'f' paramether must be str type"
    else:
        try:
            f = sympify(f)
        except:
            return "Syntax Error!"
        if ((len(f.atoms(Symbol)) > 1) or (not x in f.atoms(Symbol))):
            print("Syntax Error!")
            return
        if isinstance(xk, float) or isinstance(xk, int):
            if isinstance(tol, float) or isinstance(tol, int):
                fk = f.subs(x, xk).evalf()
                iter = 0

                x_values = [iter]
                y_values = [abs(fk)]
                while abs(fk) > tol:
                    if (f.subs(x, xk + fk).evalf() - fk) == 0:
                        break
                    xk = xk - fk ** 2 / (f.subs(x, xk + fk).evalf() - fk)
                    fk = f.subs(x, xk).evalf()
                    iter += 1
                    x_values.append(iter)
                    y_values.append(abs(fk))
                if graff == 1:
                    graph(x_values, y_values, "Steffensen's method to: f(x)=" + str(f))
                elif graff != 0:
                    print("Warning: parameter graff must be an integer, 1 or 0")
                return xk, iter
            else:
                return "'tol' type error, must be float or integer"
        else:
            return "'xk' type error, must be float or integer"


def sne_fd_2(fun, x_a, x_b, tol, graph = 1):
    """
    Muller-Bisection Method
    It uses an interval from x_a to x_b to find an aproximation of x
    to resolve the function (fn) given by the user. It uses the Muller´s Method
    to find the new value of a third point, under the condition that this value
    have to be between a new subroutine interval, if the value isn't here it uses
    the Bisection's Method.

    Retrieved from: Wu, Xinyuan. (2005). Improved Muller method and Bisection method with global and asymptotic
    superlinear convergence of both point and interval for solving nonlinear equations. Avalaible at:
    https://tecdigital.tec.ac.cr/dotlrn/classes/IDC/CE3102/S-2-2019.CA.CE3102.1/
    file-storage/view/Tareas%2Ftarea-1%2Fart-culos-cient-ficos%2F1-s2.0-S0096300304004382-main.pdf

    :param x_a: initial value for the interval
    :param x_b: final value for the interval
    :param x_b: final value for the interval
    :param fun: math expression to evaluate
    :param tol: minimum approach tolerance
    :param graph: Integer, 1 or 0
    :return: Tuple, [x aproximation, iterations]
    """
    if not(isinstance(x_a, float) or isinstance(x_a, int)) \
        or not(isinstance(x_b, float) or isinstance(x_b, int)):
        print("Error, interval its not valid")
        return

    if not(isinstance(tol, float) or isinstance(tol, int)):
        print("Error, tolerance isn't a valid number")
        return

    fun = sympify(fun)

    f = sympify(fun)
    variable = f.atoms(Symbol)
    if len(variable) > 1:
        return " Error: The f expression has more than one variables"
    if not x in variable:
        return " Error: The expression f doesn't have x as a variable"

    x_c = x_a + (x_b - x_a) / 2
    x_aa = 0
    x_bb = 0
    iter = 0

    #Function Evaluation
    x_a_eval = fun.subs(x, x_a).evalf()
    x_b_eval = fun.subs(x, x_b).evalf()
    x_c_eval = fun.subs(x, x_c).evalf()
    y_values = []

    #Validations
    if(x_a > x_b):
        print("Error, enter a valid interval")
        return
    elif x_a_eval * x_b_eval > 0:
        print("The existence of one or a single zero in the "
              "given interval cannot be guaranteed.")
        return

    #Subroutine interval
    if x_c_eval == 0:
        y_values.append(abs(x_c_eval))
        return x_c_eval, 0
    elif x_a_eval * x_c_eval < 0:
        x_aa = x_a
        x_bb = x_c
    elif x_b_eval * x_c_eval < 0:
        x_aa = x_c
        x_bb = x_b

    x_c_new = muller_algorithm(x_a, x_b, x_c, fun)
    x_values = [iter]
    y_values.append(x_c_new)
    while(abs(fun.subs(x, x_c_new).evalf()) >= tol):
        x_aa_eval = fun.subs(x, x_aa).evalf()
        x_bb_eval = fun.subs(x, x_bb).evalf()
        x_new_eval = fun.subs(x, x_c_new).evalf()

        if x_aa < x_c_new < x_bb:
            if x_c_new == 0:
                return x_c, iter
            elif x_aa_eval * x_new_eval < 0:
                x_aa = x_a
                x_bb = x_c_new
            elif x_bb_eval * x_new_eval < 0:
                x_aa = x_c_new
                x_bb = x_b
        else:
            x_c = x_aa + (x_bb - x_aa) / 2
        iter = iter + 1
        x_c_new = muller_algorithm(x_aa, x_bb, x_c, fun)
        x_values.append(iter)
        y_values.append(abs(fun.subs(x, x_c_new).evalf()))
    if graph == 1:
        graph(x_values, y_values, "Muller-Bisection method f(x)")
    elif graph != 0:
        print("Warning: parameter graff must be an integer, 1 or 0")
    return x_c_new, iter


def sne_fd_3(f, x2, x1, x0, tol, graff = 1):
    '''
    Inverser quadratic interpolation's method consists in aproximated 
    the inverse of f, the method need three initial values, integers o 
    floats. The return of method is the value aproximate for x and the number
    of iterations. 
    
    Reference: Mark James Magnaye, M. J. B. M. (n.d.-a). 
    Inverse Quadratic Interpolation Method. Retrieved August 20, 2019, 
    from https://www.academia.edu/8121176/Inverse_Quadratic_Interpolation_Method
    
    :param x2: (Type FLOAT/ INTEGER) First initial Value
    :param x1: (Type FLOAT/ INTEGER) Second initial Value
    :param x0: (Type FLOAT/ INTEGER) Third initial Value
    :param tol:(Type FLOAT/ INTEGER) approach tolerance
    :param f: (Type string) math function
    :param graff: (Type INTEGER) 1 to shown the graphic and 0 to don't shown
    :return: (Type TUPLE X) approximate and number of iterations
    '''
    if not isinstance(f, str):
        return "Error : f paramether must be a str type"  
    f = sympify(f)
    variable = f.atoms(Symbol)
    if len(variable) > 1:
        return " Error: The f expression has more than one variables"  
    if not x in variable:
        return " Error: The expression f doesn't have x as a variable"
    if (not isinstance(x2, int) and not isinstance(x1, int) and 
        not isinstance(x0, int) and not isinstance(x2, float) and 
        not isinstance(x1, float) and not isinstance(x0, float)):
        print("Error: Incorrect initial values")
        return;
    if not(isinstance(tol, float)) and not(isinstance(tol, float)):
        print("Error: Incorrect tolerance")
        return;
    try:
        termino1 = (f.subs(x, x1).evalf() * f.subs(x, x2).evalf() * x0 /
                    ((f.subs(x, x0).evalf() - f.subs(x, x1).evalf()) * 
                     (f.subs(x, x0).evalf() - f.subs(x, x2).evalf())))  
        termino2 = (f.subs(x, x0).evalf() * f.subs(x, x2).evalf() * x1 / 
                    ((f.subs(x, x1).evalf() - f.subs(x, x0).evalf()) * 
                     (f.subs(x, x1).evalf() - f.subs(x, x2).evalf())))
        termino3 = ((f.subs(x, x0).evalf() * f.subs(x, x1).evalf() * x2) / 
                    ((f.subs(x, x2).evalf() - f.subs(x, x0).evalf()) * 
                     (f.subs(x, x2).evalf() - f.subs(x, x1).evalf())))
        x_sig = termino1 + termino2 + termino3
        iteracion = 1
        valores_x = [iteracion]
        valores_y = [abs(f.subs(x, x_sig).evalf())]
        while abs(x_sig - x2) >= tol:
            x0 = x1
            x1 = x2
            x2 = x_sig
            termino1 = ((f.subs(x, x1).evalf() * f.subs(x, x2).evalf() * x0) / 
                        ((f.subs(x, x0).evalf() - f.subs(x, x1).evalf()) * 
                         (f.subs(x, x0).evalf() - f.subs(x, x2).evalf()) )) 
            termino2 = ((f.subs(x, x0).evalf() * f.subs(x, x2).evalf() * x1) / 
                        ((f.subs(x, x1).evalf() - f.subs(x, x0).evalf()) * 
                         (f.subs(x, x1).evalf() - f.subs(x, x2).evalf())))
            termino3 = ((f.subs(x, x0).evalf() * f.subs(x, x1).evalf() * x2) / 
                        ((f.subs(x, x2).evalf() - f.subs(x, x0).evalf()) * 
                         (f.subs(x, x2).evalf() - f.subs(x, x1).evalf())))
            x_sig = termino1 + termino2 + termino3
            iteracion += 1
            valores_x.append(iteracion)
            valores_y.append(abs(f.subs(x, x_sig).evalf()))
        if graff == 1:
            graph(valores_x, valores_y,(
                    "Inverse Quadratic interpolation method: f(x)=" + str(f)))
        elif graff != 0:
            print("Warnings: The graff value must be an integer, 0 or 1")
        return x_sig, iteracion
    except ZeroDivisionError:
        print("Error: Division by zero")
        return x_sig, iteracion


def sne_fd_4(f, a, b, tol, graff = 1):
    '''
   The Ridders method is based on the method a false position to 
   calculate the root of x, this method uses an exponential function
   to adjust the value of x. The funtion need an initial interval 
   where there is a zero of the function and returns an approximate 
   value a that zero.
   
    Reference:Modesto Mas, M. M. (2016b, June 24). Ridders' method in Julia. 
    Retrieved August 25, 2019, from https://mmas.github.io/ridders-julia
    
    :param a: (Type INTEGER/ FLOAT) Initial interval point
    :param b: (Type INTEGER/ FLOAT) End interval point
    :param tol: (Type INTEGER/ FLOAT) approach tolerance
    :param f: (Type string ) math function
    :param graff: (Type INTEGER/ FLOAT) Integer, 1 to shown the graphic and 0 to don't shown
    :return: (Type TUPLE) x approximate and number of iterations
    '''
    if not isinstance(f, str):
        return "Error : f paramether must be a str type"
    f = sympify(f)
    variable = f.atoms(Symbol)
    if len(variable) > 1:
        return " Error: The f expression has more than one variables"  
    if not x in variable:
        return " Error: The expression f doesn't have x as a variable"
    if(not isinstance(a, int) and not isinstance(b, int ) and
       not isinstance(a, float) and not isinstance(b, float) ):
        print ("Error: Initial values incorrect")
        return;
    if not isinstance(tol, float) and not isinstance(tol, int):
        print("Error: Invalid tolerance")
        return;
    if f.subs(x, a).evalf() * f.subs(x, b).evalf() < 0:        
        try:
            x1 = a
            x2 = b
            iteraciones  = 1
            x3 = (x1 + x2)/2 
            signo = ((f.subs(x, x1).evalf() - f.subs(x, x2).evalf()) /
                    abs(f.subs(x, x1).evalf() - f.subs(x, x2).evalf()))
            x4 = (x3 + signo * (f.subs(x, x3).evalf() * (x3 - x1) / 
                sqrt(f.subs(x, x3).evalf()**2 - f.subs(x ,x1).evalf() * 
                                          f.subs(x, x2).evalf())))
            valores_x = [iteraciones]
            valores_y = [abs(f.subs(x, x4).evalf())]
            while abs(f.subs(x, x4).evalf()) >= tol:
                if f.subs(x, x4).evalf() > 0:
                     x2 = x4
                else:
                    x1 = x4
                x3 = (x1 +x2)/2 
                signo = ((f.subs(x, x1).evalf() - f.subs(x, x2).evalf()) /
                         abs(f.subs(x, x1).evalf() - f.subs(x, x2).evalf()))
                x4 = (x3 + signo * (f.subs(x, x3).evalf() * (x3 - x1) / 
                sqrt(f.subs(x, x3).evalf()**2 - f.subs(x ,x1).evalf() * 
                                              f.subs(x, x2).evalf())))
                iteraciones  += 1
                valores_x.append(iteraciones)
                valores_y.append(abs(f.subs(x, x4).evalf()))
            if graff == 1:
                graph(valores_x, valores_y, "Ridders method: f(x)=" + str(f))
            elif graff != 0:
                print("Warning: The graff value must be an integer, 0 or 1")
            return x4, iteraciones
        except ZeroDivisionError:
            print("Warning: Division by zero")
            return x4, iteraciones


def sne_fd_5(f, x0, x1, tol, graf = 1):
    """
    Computes an aproximation of a zero of a function f with the Brent-Dekker's
    Method. It uses the parameters 'x0' and 'x1' as the initial values
    required for the iterations.
    It returns the aproximation of the zero with a precision of 'tol', the
    number of iterations required to find the solution and a graph of the
    number of iterations versus the error; only if its required.

    Retrieved from: Zhengqiu Zhang (2011). An Improvement to the Brent’s
    Method, International Journal of Experimental Algorithms (IJEA), Volume 2.
    Chinese Academy of Meteorological Sciences.
    
    :param f: symbolic expression of the equation
    :type f: string

    :param x0: first initial value
    :type x0: int or float
	
    :param x1: second initial value
    :type x1: int or float

    :param tol: amount of precision on the result
    :type tol: float
	
    :param graf: flag that determines if the method needs to return a graph
    :type graf: 1 or 0 (1 by default)
                
    You need to install the SymPy and MatPlotLib package before using this
    method.
    
    :example: 'sne_fd_5("x ** 2 - 2", 1, 2, 0.0001)'
    """
    if(not isinstance(f, str)):
        print("The initial value 'f' must be a string!")
        return
    try:
        f = sympify(f)
    except:
        print("Syntax Error!")
        return
    if ((len(f.atoms(Symbol)) > 1) or (not x in f.atoms(Symbol))):
        print("Syntax Error!")
        return
    
    if(isinstance(x0, complex) or isinstance(x1, complex) \
       or isinstance(tol, complex)):
        print("The initial values 'x0', 'x1' and 'tol' must be real numbers!")
        return
    
    bolzano = f.subs(x, x0).evalf() * f.subs(x, x1).evalf()
    xk = x0
    k = 0
    x_vector = [k]
    y_vector = [abs(f.subs(x, xk).evalf())]
    if(bolzano > 0):
        print("Error: The existence of a zero can't be guaranteed by the \
Bolzano's Theorem!")
    else:
        try:
            if(abs(f.subs(x, x0).evalf()) < abs(f.subs(x, x1).evalf())):
                temp = x1
                x1 = x0
                x0 = temp
                
            xk = x0
            x2 = x0
            x3 = x0
            flag = True
            while(abs(f.subs(x, xk).evalf()) > tol):
                if((f.subs(x, x0).evalf() != f.subs(x, x2).evalf()) \
                   and (f.subs(x, x1).evalf() != f.subs(x, x2).evalf())):
                    
                    t1 = (x0 * f.subs(x, x1).evalf() * f.subs(x, x2).evalf()) \
                         / ((f.subs(x, x0).evalf() - f.subs(x, x1).evalf()) \
                            * (f.subs(x, x0).evalf() - f.subs(x, x2).evalf()))
                    t2 = (f.subs(x, x0).evalf() * x1 * f.subs(x, x2).evalf()) \
                         / ((f.subs(x, x1).evalf() - f.subs(x, x0).evalf()) \
                            * (f.subs(x, x1).evalf() - f.subs(x, x2).evalf()))
                    t3 = (f.subs(x, x0).evalf() * f.subs(x, x1).evalf() * x2) \
                         / ((f.subs(x, x2).evalf() - f.subs(x, x0).evalf()) \
                            * (f.subs(x, x2).evalf() - f.subs(x, x1).evalf()))
                    xk = t1 + t2 + t3
                else:               
                    denominator = f.subs(x, x1).evalf() - f.subs(x, x0).evalf()
                    xk = x1 - f.subs(x, x1).evalf() * ((x1 - x0) / denominator)
              
                if(((xk < ((3 * x0 + x1) / 4)) and (xk > x1)) or \
                    (flag and (abs(xk - x1) >= abs((x1 - x2) / 2))) or \
                    ((not flag) and (abs(xk - x1) >= abs((x2 - x3) / 2))) or \
                    (flag and (abs(x1 - x2) < abs(tol))) or \
                    ((not flag) and (abs(x2 - x3) < abs(tol)))):
                    
                    xk = (x0 + x1) / 2
                    flag = True
                else:
                    flag = False
                x3 = x2
                x2 = x1
                
                bolzano = f.subs(x, x0).evalf() * f.subs(x, xk).evalf()
                if(bolzano <= 0):
                    x1 = xk
                else:
                    x0 = xk
                    
                if(abs(f.subs(x, x0).evalf()) < abs(f.subs(x, x1).evalf())):
                    temp = x1
                    x1 = x0
                    x0 = temp
                    
                k = k + 1
                x_vector.append(k)
                y_vector.append(abs(f.subs(x, xk).evalf()))
        except ZeroDivisionError:
            print("You can't divide by zero!\nThe process has been stopped!")
        if(graf == 1):
            graph(x_vector, y_vector, "Brent-Dekker's method to: f(x)=" + str(f))
        return xk, k


def sne_fd_6(f, x0, x1, tol, graf = 1):
    """
    Computes an aproximation of a zero of a function f with the
    Anderson-Bjorck's Method. It uses the parameters 'x0' and 'x1' as the
    initial values required for the iterations.
    It returns the aproximation of the zero with a precision of 'tol', the
    number of iterations required to find the solution and a graph of the
    number of iterations versus the error; only if its required.

    Retrieved from: Sérgio Galdino (2011). A family of regula falsi
    root-finding methods, Proceedings of 2011 World Congress on Engineering and
    Technology, Volume 1.
    
    :param f: symbolic expression of the equation
    :type f: string

    :param x0: first initial value
    :type x0: int or float

    :param x1: second initial value
    :type x1: int or float

    :param tol: amount of precision on the result
    :type tol: float

    :param graf: flag that determines if the method needs to return a graph
    :type graf: 1 or 0 (1 by default)
                
    You need to install the SymPy and MatPlotLib package before using this
    method.
    
    :example: 'sne_fd_6("x ** 2 - 2", 1, 2, 0.0001)'
    """
    if(not isinstance(f, str)):
        print("The initial value 'f' must be a string!")
        return
    try:
        f = sympify(f)
    except:
        print("Syntax Error!")
        return
    if ((len(f.atoms(Symbol)) > 1) or (not x in f.atoms(Symbol))):
        print("Syntax Error!")
        return
    
    if(isinstance(x0, complex) or isinstance(x1, complex) \
       or isinstance(tol, complex)):
        print("The initial values 'x0', 'x1' and 'tol' must be real numbers!")
        return
    
    bolzano = f.subs(x, x0).evalf() * f.subs(x, x1).evalf()
    xk = x0
    k = 0
    x_vector = [k]
    y_vector = [abs(f.subs(x, xk).evalf())]
    if(bolzano > 0):
        print("Error: The existence of a zero can't be guaranteed by the \
Bolzano's Theorem!")
    else:
        try:
            xk_1 = x0
            sign = 0
            while(abs(f.subs(x, xk).evalf()) > tol):
                if(k == 0):
                    xk = (x0 * f.subs(x, x1).evalf() \
                          - x1 * f.subs(x, x0).evalf()) \
                         / (f.subs(x, x1).evalf() \
                            - f.subs(x, x0).evalf())
                    
                else:
                    m = 1 - f.subs(x, xk).evalf() / f.subs(x, xk_1).evalf()
                    if(m < 0):
                        m = 0.5
                        
                    if(sign < 0):
                        xk = (x0 * f.subs(x, x1).evalf() \
                              - m * x1 * f.subs(x, x0).evalf()) \
                              / (f.subs(x, x1).evalf() \
                                 - m * f.subs(x, x0).evalf())
                    else:
                        xk = (m * x0 * f.subs(x, x1).evalf() \
                              - x1 * f.subs(x, x0).evalf()) \
                              / (m * f.subs(x, x1).evalf() \
                                 - f.subs(x, x0).evalf())
                        
                bolzano = f.subs(x, x0).evalf() * f.subs(x, xk).evalf()
                if(bolzano <= 0):
                    xk_1 = x1
                    x1 = xk
                    sign = -1
                else:
                    xk_1 = x0
                    x0 = xk
                    sign = 1
                    
                k = k + 1
                x_vector.append(k)
                y_vector.append(abs(f.subs(x, xk).evalf()))
        except:
            print("You can't divide by zero!\nThe process has been stopped!")
        if(graf == 1):
            graph(x_vector, y_vector, "Anderson-Bjorck's method to: f(x)=" + str(f))
        return xk, k
