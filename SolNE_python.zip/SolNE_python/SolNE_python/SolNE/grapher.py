import matplotlib.pyplot


def graph(axis_x, axis_y, title):
    """
    Makes graphs to see Iterations vs |f(x)| evaluations
    :param axis_x: Array with numeric values to x axis
    :param axis_y: Array with numeric values to y axis
    :param title: String - graph's name
    :return: Shows graph
    """

    matplotlib.pyplot.plot(axis_x, axis_y)

    matplotlib.pyplot.axhline(0, color="black")
    matplotlib.pyplot.axvline(0, color="black")
    matplotlib.pyplot.xlabel("Iterations", fontdict=None, labelpad=None)
    matplotlib.pyplot.ylabel("|f(x)|", fontdict=None, labelpad=None)
    matplotlib.pyplot.title(title)

    matplotlib.pyplot.show()

